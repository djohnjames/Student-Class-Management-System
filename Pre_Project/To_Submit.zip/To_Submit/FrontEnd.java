/**
 * This class is used to run the GUI
 * @author Dylan Rae and Tyler Sawatzky
 * @version 1.0
 * @since April 6, 2020
 *
 */
public class FrontEnd {

	public static void main(String[] args) {
		GUI myGUI = new GUI("Home", 700, 350);

	}

}
